struct node *creatnode();
struct node *creatlinklist();
int insertnode();
struct node *deletenode();
int sortlinklist();
int displaylinklist();
struct node
{
	int info;
	struct node *Next;	
};
//struct node* start=NULL;
int main();
int sortlinklist();
int displaymenu();
extern int i;
extern int j;
